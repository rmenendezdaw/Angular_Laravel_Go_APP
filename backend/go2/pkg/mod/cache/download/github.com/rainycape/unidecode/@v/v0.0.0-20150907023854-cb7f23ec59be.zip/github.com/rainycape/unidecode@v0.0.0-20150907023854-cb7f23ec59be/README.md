unidecode
=========

Unicode transliterator in Golang - Replaces non-ASCII characters with their ASCII approximations.

[![GoDoc](https://godoc.org/github.com/rainycape/unidecode?status.svg)](https://godoc.org/github.com/rainycape/unidecode)
