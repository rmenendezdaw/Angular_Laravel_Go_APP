// No build tag in this file.

package main

type Const int

const (
	A Const = iota
	B
	C
)
